<?php
class Department extends MY_Controller
{
    // 一覧画面表示
    public function index() {
        // VIEWキャッシュ
        // if (VIEW_CACHE_EXPIRES) $this->output->cache(VIEW_CACHE_EXPIRES);

        $this->_model->relate_names = ['schedule']; // 関連データを取得しない
        $data = []; 
        $tmpl = 'index';
        $target_categories = [];
        $segments = explode('/',parse_url(current_url())['path']);
        if( $segments[2] === 'special_foreign' ){
            $tmpl = 'special_foreign';
            $target_categories = [DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT];
        }
        else if( $segments[2] === 'kango_care' ){
            $tmpl = 'kango_care';
            $target_categories = [DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT];
        }
        else {
            $target_categories = [
                DEPARTMENT_CATEGORY_MEDICAL_SPECIALTY,
                DEPARTMENT_CATEGORY_CENTRAL_MEDICAL_FACILITY,
                DEPARTMENT_CATEGORY_INTEGRATIVE_TREATMENT_DIAGNOSTICS,
                DEPARTMENT_CATEGORY_MEDICAL_SUPPORT,
                DEPARTMENT_CATEGORY_ADMIN_NURSING_CHIEF,
            ];
        }

        $results = $this->_model->search([
            'where_in' => [
                'category_id' => $target_categories
            ] 
        ], $pager, true);

        $data['departments'] = [];
        foreach($results as $d){
            $data['departments'][$d['category_id']][] = [
                'name'         => $d['name'],
                'detail_url'   => $d['detail_url'],
                'schedule_url' => !empty($d['schedule_url'])?
                                  $d['schedule_url'] : null
            ];
        }

        if( $tmpl === 'index'){
            // $data['sidebar_departments'] = $data['departments'][DEPARTMENT_CATEGORY_MEDICAL_SPECIALTY];
            $data['category_id'] = DEPARTMENT_CATEGORY_MEDICAL_SPECIALTY;
        }
        else if( $tmpl === 'special_foreign'){
            $data['sidebar_departments'] = $data['departments'][DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT];
            $data['category_id'] = DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT;
        }
        else if( $tmpl === 'kango_care'){
            $data['sidebar_departments'] = $data['departments'][DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT];
            $data['category_id'] = DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT;
        }

        if( $tmpl === 'index'){
            $this->load_model(['Faq']);
            $faqs = $this->Faq->search([
                'where' => [
                    "(FIND_IN_SET('".FAQ_DISP_PLACE_DEPARTMENT."', disp_place))" 
                ]
            ], $pager, true);

            $this->load->vars(compact('faqs'));
        }

        $searth_type = !empty(set_value('kana_index')) ? 'kana_index': '';
        $this->load->view($this->_controller_name.'/'. $tmpl, compact('data','searth_type'));
    }

    //public function search () {

    //    if (empty($_REQUEST['yomi']) || mb_strpos('あかさたなはやまらわ',$_REQUEST['yomi'])===false) {
    //        // 読みの指定なしか、不正な場合は「あ」行の検索とする
    //        $_POST['yomi'] = $_GET['yomi'] = $_REQUEST['yomi'] = 'あ';
    //    }

    //    $results = $this->_model->search(null, $pager, true);
    //    $data = [
    //        'results' => $results,
    //        'pager' => array_merge($pager, ['config'=>['base_url' => base_url(uri_string())]]),
    //    ];
    //    $this->load->view($this->_controller_name.'/search', compact('data'));
    //}

    public function detail ($dirname, $action=null) {
        // VIEWキャッシュ
        // if (VIEW_CACHE_EXPIRES) $this->output->cache(VIEW_CACHE_EXPIRES);
        
        $orig_mode = $this->_model->preview_mode;
        if ($this->my_session->allow_preview && $this->input->get('preview')) {
            // プレビュー許可ユーザ、かつプレビューモードでの表示
            $this->_model->preview_mode = true;
        }
        $data = $this->_model->get_by_dirname($dirname);
        if (empty($data)) {
            show_404();
        }

        $segments = explode('/',parse_url(current_url())['path']);
        if( empty($segments[2]) ) show_404();

        if( 
            $data['category_id'] == DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT &&
            $segments[2] != 'special_foreign'
        ) show_404();

        if( 
            $data['category_id'] == DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT &&
            $segments[2] != 'kango_care'
        ) show_404();

        if(
            $data['category_id'] != DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT  &&
            $data['category_id'] != DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT &&
            $segments[2] != 'departments'
        ) show_404();

        $this->_model->relate_names = []; // 関連データを取得しない
        $data['sidebar_departments'] = $this->_model->search([
            'where' => [
                'category_id' => $data['category_id']
            ]
        ]);

        if( empty($action) ) $action = 'detail';
        $this->_model->preview_mode = $orig_mode;
        $this->load->view($this->_controller_name."/{$action}", ['data'=>$data, 'dirname'=>$dirname]);
    }

    // リアルタイムプレビュー表示
    public function preview_changes()
    {
        if ( empty($_POST) || $this->my_session->admin == false) {
            show_404();
        }
        $this->_model->preview_mode = true;
        $data = $_POST;

        if( !empty($data['result_title']) ){
            $max = count($data['result_title']);
            $data['results'] = [];
            for ($i = 0; $i < $max; $i++) {
                $data['results'][] = [
                    'title'=> $data['result_title'][$i],
                    'html' => $data['result_html'][$i]
                ];
            }
        }
        $this->load->view($this->_controller_name.'/detail', ['data'=>$data]);
    }

    public function sidebar ($dirname) {
        $data = $this->_model->get_by_dirname($dirname);
        if (empty($data)) return '';

        $this->_model->relate_names = []; // 関連データを取得しない
        $data['sidebar_departments'] = $this->_model->search([
            'where' => [
                'category_id' => $data['category_id']
            ]
        ]);

        $this->load->view($this->_controller_name."/sidebar", 
            ['data'=>$data, 'dirname'=>$dirname]);
    }

    public function search_doctor () {

        $this->load_model(['Doctor']);

        $keywords = trim(mb_convert_kana(set_value('qd'), 'asHcV', 'UTF-8'));
		$keywords = explode(' ', $keywords);

        $where_sql = [];
        foreach($keywords as $keyword){
            $conditions = [];
            $conditions[] = "name like '%". $this->db->escape_like_str($keyword)."%'";
            $conditions[] = "name_kana like '%". $this->db->escape_like_str($keyword)."%'";
            $where_sql[] = '('. implode(' OR ', $conditions) .')';
        }
        
        $results = $this->Doctor->search([
            'where'=> [ implode(' AND',$where_sql) ],
        ], $pager, true);

        $searth_type = 'doctor';
        $this->load->view($this->_controller_name."/search_doctor",
            compact('results','searth_type') );
    }

    public function preview_page($id_md5)
    {
        $result = $this->_model->get_data_for_preview($id_md5);
        if( empty($result) ) show_404();
        $data = $result;
        if( !empty($data['result_title']) ){
            $data['results'] = [];
            foreach( $data['result_title'] as $i => $j ){
                $data['results'][] = [
                    'title' =>  $data['result_title'][$i],
                    'html'  =>  $data['result_html'][$i]
                ];
            }
        }
        $this->load->view($this->_controller_name.'/detail', compact('data'));
    }
}
