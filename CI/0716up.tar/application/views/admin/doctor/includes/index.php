<?php /* 検索結果テンプレート */ ?>
<style type="text/css">
img.doctor-face {
    width: 50px;
    margin-right: .5rem;
}
</style>
<?php
$department_options = DepartmentConf::name_options();
?>
<div class="list-box clearfix">

    <div class="search-box clearfix">

            <div id="conditions">

                <?php echo form_open_multipart($this_url, ['novalidate'=>'novalidate', 'method'=>'get']); ?>

                <?php echo admin_search_row(
                    admin_form_input_raw('keyword', null),
                    'name',
                    [
                        // 'notice'=>lang('name'). 'が検索対象になります',
                    ],
                    'col-md-12 col-lg-8'); ?>

                <!-- 詳細検索 -->
                <div class="detail-search">
                    <a href="#detail-search-body" data-toggle="collapse"><i class="fas fa-plus-circle"></i> 検索条件をより細かく設定する</a>
                    <div class="detail-search-body collapse" id="detail-search-body">

                        <?php
                        echo admin_search_row(
                            admin_form_dropdown_raw('department', $department_options, null, ['empty'=>'指定なし',]),
                            lang('department_id'),
                            null,
                            'col-auto'
                        ); ?>

                        <?php echo admin_search_row(
                        admin_form_radio_raw('published', ['0'=>'非公開', '1'=>'公開'], null, ['empty'=>'指定なし',]),
                        '公開状態',
                        ['inline'=>true],
                        'col-md-12'); ?>

                        <?php echo admin_search_row(
                            admin_form_checkbox_raw('draft', ['1'=>'公開取下げのみ'], null, null),
                            '',
                            ['inline'=>true],
                            'col-md-6'); ?>

                    </div>
                </div>

                <?php echo admin_search_buttons(); ?>

                <?php echo form_close(); ?>

            </div><!--//#conditions-->


    </div>
    <!-- //.search-box -->
</div><!-- //.list-box -->

<div class="list-box clearfix">

    <?php if (!empty($results)): // データあり?>

    <?php 
        $_department_options = [];
        foreach($department_options as $group => $options){
            foreach($options as $id => $name){
                $_department_options[$id] = $group.'/'.$name;
            }
        }
        $department_options = $_department_options;
    ?>
    <div class="search-controller">
        <?php echo admin_batch_menu()?>
        <?php echo admin_pagination($pager, ['limits'=>$search_limits, 'pager_enabled'=>false]) ?>
    </div>

    <?php
    // テーブルをレスポンシブ対応にしない場合、
    // class="table-responsive"を削除すればテーブルは画面幅100%（スクロールバーは常に出ない）で設定されます。
    // また、レスポンシブ対応にするの場合のテーブルの最低幅については
    // ipadの縦表示でスクロールバーが出ないように最適化されています(テーブル幅は690px程度)
    // もし最低幅を指定したい場合、tableタグに対し、style="min-width: xxxpx" を設定してください。
    // ※thに設定するwidthに依っては、table全体の幅がmin-widthで設定した幅よりも大きくなる場合があります。
    // どうしてもipadサイズでスクロールバーを出したくない場合は列を削除するか、thの幅を調整するかする必要あり。
    ?>
    <div class="table-responsive reverse-scroll">
        <table class="table table-bordered dataTable" style="">
            <thead>
                <tr>
                    <th class="sorting" style="width:3rem"><input type="checkbox" value="1" class="batch_all" /></th>
                    <th class="sorting" style="width:4rem"><?php echo sort_link('id', 'ID'); ?></th>
                    <th class="sorting" style="">所属部門 / <?php echo sort_link('name', 'name'); ?></th>
                    <th class="sorting" style="width:8rem"><?php echo sort_link('staff_number', 'staff_number'); ?></th>
                    <th class="sorting" style="width:10rem">公開状態</th>
                    <th class="sorting" style="width:13.3rem">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($results as $v):?>
                <tr class="<?php echo $v['published']?'':'disabled' ?>">
                    <td><input type="checkbox" value="<?php echo h($v['id']);?>" class="batch" /></td>
                    <td class="text-sm"><?php echo h($v['id']); ?></td>
                    <td class="text-left">
                      <div class="float-left">
                      <?php

                      $_html = '';
                      if (!empty($v['department_id'])) {
                          foreach ($v['department_id'] as $dep_id) {
                              $_html .= '<span class="badge badge-pill badge-category">'.opt($dep_id, $department_options). '</span>';
                          }
                      }
                      if( !empty($v['is_temporary']) ){
                          $_html .= '<span class="ml-2 badge badge-warning -temporary">一時保存</span>';
                      }

                      if( !empty($_html) ) echo $_html.'<br>';
                      echo '<span style="font-size:1rem">'.h($v['name'],'(未設定)').'</span>';
                      if( !$v['published'] || !empty($v['is_temporary']) ){
                          echo '<a href="'.base_url( $controller.'/preview_page/'. md5($v['id']) ).'" 
                              style="font-size:.6rem" target="_blank"><i class="fas fa-clone ml-2 small"></i> 一時保存のプレビューを見る</a>';
                      }
                      ?>
                      </div>
                      <?php
                      if ($v['face_image_path']) {
                          echo '<div class="float-right">';
                          echo '<img src="'.h($v['face_image_path']).'" class="doctor-face">';
                          echo '</div>';
                      }
                      ?>
                    </td>
                    <td class="text-center">
                        <?= h($v['staff_number']) ?>
                    </td>
                    <td class="text-center">
                        <?php
                        $help = '';
                        if (!empty($v['published'])) { // 公開中
                            $label = '公開中';
                        } else { // 非公開中
                            $label = '非公開';
                        }
                        ?>
                        <?php echo h($label)?>
                        <?php echo empty($v['flg_publish']) ? '<br><small>（公開取下げ）</small>' : ''; ?>
                    </td>
                    <td>
                        <?php echo admin_list_menu(
                            $v['id'],
                            [
                                // 公開フラグがONなら非表示、そうでなければバリデート済みなら表示、バリデートがまだであれば無効
                                'publish' => !!$v['flg_publish']
                                                ? false
                                                : (!!$v['validated']
                                                    ? true : 'disabled'),
                                // 公開フラグがONなら表示
                                'draft' => !!$v['flg_publish'],
                                'delete_confirm' => "ID:{$v['id']} を削除します。\\n削除すると、部門との関連は削除されます。\\nよろしいですか？",
                            ]
                        )?>
                    </td>
                </tr>
                <?php endforeach;?>
            </tbody>
        </table>
    </div><!--//.table-responsive-->

    <div class="search-controller full">
        <?php echo admin_pagination($pager, ['limits'=>$search_limits]) ?>
    </div>

    <?php else: ?>
        <div class="alert alert-info" role="alert">
            データが見つかりませんでした。
        </div>
    <?php endif?>

</div>
<!--//.list-box -->
