<?php /* 検索結果テンプレート */ ?>

<div class="list-box clearfix">

<div class="search-controller">
    <a href="<?php echo admin_base_url("/{$controller}/{$department_id}/edit") ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> 新規登録</a>
</div>

<div class="controller-left mb-3">

<?php if( !empty($data['results']) ){ ?>
<ul class="list-group sortable">
  <?php foreach($data['results'] as $page){ //pr($page); ?>
  <?php

        $parent_page_uri = '';
        if( $department['category_id'] == DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT ){
            $parent_page_uri = '/treatment/special_foreign/';
        }
        else if( $department['category_id'] == DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT ){
            $parent_page_uri = '/treatment/kango_care/';
        }
        else {
            $parent_page_uri = '/treatment/departments/';
        }

        $parent_page_uri .= $department['dir_name'].'/';
  ?>
  <li class="list-group-item" id="<?php echo $page['id'] ?>">
    <div class="row ml-1">
        <div class="col-10 item-left">
          <i class="fa fa-file"></i>
          <?php echo $parent_page_uri ?><?php echo $page['directory_path'] ?>
           <br>[ <?php echo $page['title'] ?> ]
          <?php if( !empty($page['is_temporary']) ){ ?><span class="badge badge-warning -temporary">一時保存</span><?php } ?>
          <?php if( empty($page['flg_publish']) ){ ?><span class="badge badge-light p-1">下書き</span><?php } ?>
          <div class='mt-2 ml-2'>
            <?php echo site_url($parent_page_uri.$page['directory_path']) ?>
            <?php if( !empty($page['flg_publish']) ){ ?>
                <a href='<?php echo base_url($parent_page_uri.$page['directory_path']) ?>' target='_blank'><i class="fa fa-external-link" aria-hidden="true"></i></a>
            <?php }else{ ?>
                <a href='<?php echo admin_preview_url($parent_page_uri.$page['directory_path']) ?>' target='_blank'><i class="fa fa-external-link" aria-hidden="true"></i></a>
            <?php } ?>
          </div>
        <?php
            if( !empty($page['is_temporary']) ){
                echo "<div class='mt-1 ml-2'>";
                echo '<a href="'.base_url( $controller.'/preview_page/'. md5($page['id']) ).'" 
                    style="font-size:.6rem" target="_blank"><i class="fas fa-clone small"></i> 一時保存のプレビューを見る</a>';
                echo '</div>';
            }
        ?>
        </div>
        <div class="col text-right">
            <?php echo admin_list_menu(
                $page['id'],
                [
                    'edit_url' => admin_base_url("{$controller}/{$department_id}/edit/{$page['id']}"),
                    'replicate' => false,
                    'publish' => false,
                    'draft' => false,
                    'delete' => true,
                    'delete_url' => admin_base_url("{$controller}/{$department_id}/delete/{$page['id']}"),
                    'delete_confirm' => '「'.h($page['title'])."」を削除します。よろしいですか？",
                ]
            )?>
        </div>

    </div>
  </li>
  <?php } ?>
</ul>
<?php }else{ ?>
<div class="alert alert-info" role="alert">
    固定ページの登録がありません
</div>
<?php } ?>

</div>
<!--//.list-box -->

<style>

.item-left {
    margin-top: -25px;
    margin-left: 10px;
}

.content-header a {
    display:none;
}
</style>
<style>
.content-header a {
    display:none;
}
</style>

<script>
$(function(){
    $('.sortable').sortable({
        update: function(){
            $.ajax({
              url: '<?php echo admin_base_url("/{$controller}/save_order/") ?>',
              type: 'post',
              dataType: 'json',
              data: { department_id: <?= $department_id ?>, ids:$(this).sortable("toArray")},
              success: function(response){
                if (response.status === 'error') { 
                    alert('並び替え中にエラーが発生しました');
                }
              }
            });
        }
    });
});
</script>
