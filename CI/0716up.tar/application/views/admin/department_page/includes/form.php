<?php /* 編集画面と確認画面共通のテンプレート */ ?>

<?php include_once VIEWPATH.'admin/common/info_block.php'; ?>

<?php 

        $page_url = '';
        if( $department['category_id'] == DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT ){
            $page_url = '/treatment/special_foreign/';
        }
        else if( $department['category_id'] == DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT ){
            $page_url = '/treatment/kango_care/';
        }
        else {
            $page_url = '/treatment/departments/';
        }
        $page_url .= $department['dir_name'].'/';
?>

<div class="edit-box">
    <h3>基本情報</h3>
    <table class="table table-bordered dataTable">
        <tbody>
            <?php echo admin_form_row(!empty($model_id)?$model_id:'(自動で採番されます)', 'ID', null, 'col-md-8');?>
            <?php echo admin_form_input('title', null, [], 'col-lg-12');?>
            <?php echo admin_form_input('directory_path', null, ['before_input'=>$page_url, 
                    'notice'=>'※使用できる文字は半角英数字、および_(アンダースコア)、/(スラッシュ)のみです<br><span class="red">※末尾の/(スラッシュ)は削除してください</span>'], 'col-lg-4');?>
        </tbody>
        <tfoot>
        </tfoot>
    </table>
</div>

<div class="edit-box <?php echo !_is_validated('content_html')?'error':'' ?>">
    <h3>本文設定 <?php echo admin_required_badge() ?></h3>
    <?php echo admin_form_article_editor_raw(
        'content_html',
        null,
        [
            'data-inline-ve'=>1,
            'data-types'=>"['big-heading', 'mid-heading', 'text', 'image', 'vs-image', 'link-kmu', 'table', 'youtube', 'html']",
            'data-type-names'=>"{'big-heading':'大見出し', 'mid-heading':'子見出し', 'text':'テキスト', 'vs-image':'画像（PCのみ2カラム）', 'image':'画像', 'link-kmu':'リンクボタン', 'table':'表', 'youtube':'YouTube', 'html':'HTML'}",
            'data-big-heading-tag'=>'h2',
            'data-mid-heading-tag'=>'h3',
            'data-uploader-dir'=>'/content/page'
        ]
    );?>
</div>

<div class="edit-box">
    <h3>拡張設定</h3>

    <?php if (empty($confirm_flag)):?>
    <div class="alert alert-warning" role="alert">
    このセクションで設定したスタイルシート、およびスクリプトは、標準の設定を上書きするため、意図しないレイアウト崩れ、エラーを引き起こす可能性があります。慎重に設定を行ってください。
    </div>
    <?php endif?>

    <h4>CSS</h4>
    <small>&lt;style&gt;タグは不要ですので、入力しないでください。</small>
    <div class="form-row align-items-center mb-2"><div class="col-md-12">
    <?php echo admin_form_textarea_raw('stylesheet', null);?>
    </div></div>

    <h4>JavaScript</h4>
    <small>&lt;script&gt;タグは不要ですので、入力しないでください。</small>
    <div class="form-row align-items-center"><div class="col-md-12">
    <?php echo admin_form_textarea_raw('javascript', null);?>
    </div></div>
</div>

<div class="edit-box">
    <h3>ページ設定</h3>
    <table class="table table-bordered dataTable">
        <tbody>
            <?php echo admin_form_input('meta_description', null, null, 'col-md-12');?>
        </tbody>
    </table>
</div>


<!-- //.edit-box -->
<?php include_once VIEWPATH.'admin/common/publish_block.php'; ?>

<?php
if (empty($confirm_flag)) echo admin_input_buttons(['temporary' => '一時保存（公開待機）']);
else echo admin_confirm_buttons();
