<?php

// バリデーション定義
// 下書き保存時は定義されたバリデーションのうち、
// [required] [callback__required_any] のルールは
// 取り除いた上で実行されます

$config = [
    // 診療科
    'admin/department/edit' => [
        [
            'field' => 'name',
            'rules' => 'required',
        ],
        [
            'field' => 'category_id',
            'rules' => 'required',
        ],
        [
            'field' => 'dir_name',
            'rules' => 'required|valid_dirname|is_unique_by_id[departments.dir_name]|min_length[2]',
        ],
        [
            'field' => 'start_date',
            'rules' => 'valid_datetime_minute|valid_datetime_order[end_date]',
        ],
        [
            'field' => 'end_date',
            'rules' => 'valid_datetime_minute',
        ],
    ],
    // 医師
    'admin/doctor/edit' => [
        [
            'field' => 'name',
            'rules' => 'required',
        ],
    ],
    // 担当医表 担当医設定
    'admin/schedule_doctor/edit' => [
        [
            'field' => 'disp_date',
            'rules' => 'required|valid_yearmonth|callback__yearmonth_is_unique[schedule_doctors.disp_date]',
        ],
        [
            'field' => 'sort_no',
            'rules' => 'is_natural_no_zero',
        ],
    ],
    // 臨床研究
    'admin/clinical_research/edit' => [
        [
            'field' => 'category_id',
            'rules' => 'required',
        ],
        [
            'field' => 'research_department_id',
            'rules' => 'required',
        ],
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        [
            'field' => 'reference_no',
            'rules' => 'required',
        ],
    ],

    // 疾病
    'admin/disease/edit' => [
        [
            'field' => 'name',
            'rules' => 'required',
        ],
    ],

    // お知らせ編集
    'admin/news/edit' => [
        [
            'field' => 'disp_date',
            'rules' => 'required|valid_date',
        ],
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        [
            'field' => 'category_id',
            'rules' => 'required',
        ],
        [
            'field' => 'link_type',
            'rules' => 'required',
        ],
        [
            'field' => 'content_html',
            'rules' => 'callback__required_if[link_type='.NEWS_LINK_TYPE_CONTENT.']',
        ],
        [
            'field' => 'external_url',
            'rules' => 'callback__required_if[link_type='.NEWS_LINK_TYPE_URL.']',
        ],
        [
            'field' => 'attach_path',
            'rules' => 'callback__required_if[link_type='.NEWS_LINK_TYPE_ATTACH.']',
        ],
        [
            'field' => 'start_date',
            'rules' => 'valid_datetime_minute|valid_datetime_order[end_date]',
        ],
        [
            'field' => 'end_date',
            'rules' => 'valid_datetime_minute',
        ],
    ],
    // 特長
    'admin/feature/edit' => [
        [
            'field' => 'category_id',
            'rules' => 'required',
        ],
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        [
            'field' => 'start_date',
            'rules' => 'valid_datetime_minute|valid_datetime_order[end_date]',
        ],
        [
            'field' => 'end_date',
            'rules' => 'valid_datetime_minute',
        ],
    ],
    // 採用情報編集
    'admin/recruit/edit' => [
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        [
            'field' => 'category_id',
            'rules' => 'required',
        ],
        [
            'field' => 'content_html',
            'rules' => 'required',
        ],
        [
            'field' => 'start_date',
            'rules' => 'valid_datetime_minute|valid_datetime_order[end_date]',
        ],
        [
            'field' => 'end_date',
            'rules' => 'valid_datetime_minute',
        ],
    ],
    // トピックス編集
    'admin/topic/edit' => [
        [
            'field' => 'disp_date',
            'rules' => 'required|valid_date',
        ],
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        // [
            // 'field' => 'department_ids[]',
            // 'rules' => 'required',
        // ],
        [
            'field' => 'link_type',
            'rules' => 'required',
        ],
        [
            'field' => 'content_html',
            'rules' => 'callback__required_if[link_type='.TOPIC_LINK_TYPE_CONTENT.']',
        ],
        [
            'field' => 'external_url',
            'rules' => 'callback__required_if[link_type='.TOPIC_LINK_TYPE_URL.']',
        ],
        [
            'field' => 'attach_path',
            'rules' => 'callback__required_if[link_type='.TOPIC_LINK_TYPE_ATTACH.']',
        ],
        [
            'field' => 'start_date',
            'rules' => 'valid_datetime_minute|valid_datetime_order[end_date]',
        ],
        [
            'field' => 'end_date',
            'rules' => 'valid_datetime_minute',
        ],
    ],
    // FAQ編集
    'admin/faq/edit' => [
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        [
            'field' => 'category_id',
            'rules' => 'required',
        ],
        [
            'field' => 'answer',
            'rules' => 'required',
        ],
        [
            'field' => 'start_date',
            'rules' => 'valid_datetime_minute|valid_datetime_order[end_date]',
        ],
        [
            'field' => 'end_date',
            'rules' => 'valid_datetime_minute',
        ],
    ],
    
    // レジメン編集
    'admin/regimen/edit' => [
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        [
            'field' => 'pdf_label[]',
            'rules' => 'required',
        ],
        [
            'field' => 'pdf_path[]',
            'rules' => 'required',
        ],
    ],

    // コンテンツ編集
    'admin/content/edit' => [
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        [
            'field' => 'content_html',
            'rules' => 'required',
        ]
    ],

    // ユーザ編集
    'admin/user/edit' => [
        [
            'field' => AUTH_USER_FIELD,
            'rules' => 'required|is_unique_by_id[admin_users.'.AUTH_USER_FIELD.']|min_length[3]',
        ],
        [
            'field' => AUTH_PASSWORD_FIELD,
            'rules' => 'callback__validate_password_required|valid_password',
        ],
        [
            'field' => AUTH_PASSWORD_FIELD.'_confirm',
            'rules' => 'matches['.AUTH_PASSWORD_FIELD.']'
        ],
        [
            'field' => 'name',
            'rules' => 'required',
        ],
        [
            'field' => AUTH_EMAIL_FIELD,
            'rules' => 'valid_email|is_unique_by_id[admin_users.'.AUTH_EMAIL_FIELD.']',
        ]
    ],
    // ユーザ編集
    'admin/auth/reset' => [
        [
            'field' => AUTH_PASSWORD_FIELD,
            'rules' => 'required|valid_password',
        ],
        [
            'field' => AUTH_PASSWORD_FIELD.'_confirm',
            'rules' => 'matches['.AUTH_PASSWORD_FIELD.']'
        ],

    ],

    // 診療科コンテンツ編集
    'admin/department_page/edit' => [
        [
            'field' => 'title',
            'rules' => 'required',
        ],
        [
            'field' => 'directory_path',
            'rules' => 'required|valid_url_path|callback__is_unique_by_department_id[department_pages.directory_path]',
        ],
        [
            'field' => 'content_html',
            'rules' => 'required',
        ]
    ],
];

$config['admin/user/my_edit'] = $config['admin/user/edit'];

// 診療科と部門はデータが共通
$config['admin/support/edit'] = $config['admin/department/edit'];
// $config['admin/support_question/edit'] = $config['admin/department_question/edit'];
