<?php
class Admin_department_model extends MY_Model
{
    protected $_table = 'departments';
    protected $_title_field = 'name';          // 見出しとして使用するフィールド名

    // 実績テーブル
    protected $_results_table = 'department_results';

    // limitを設定すると、[20件 50件 100件 全件]などの
    // ユーザによるlimit選択機能が使用できなくなるので注意
    protected $_search_options = [
        'order_by' => ['modified'=>'DESC', 'id'=>'DESC'],
    ];
    protected $_search_fields = [ // 検索処理用の定義
        'type' => ['type'=>'value', 'field'=>'type'],
        'keyword' => ['type'=>'query', 'method'=>'_search_keyword', 'field'=>['name','search_text']],
        'published' => ['type'=>'query', 'method'=>'_search_published'],
        'draft' => ['type'=>'query', 'method'=>'_search_draft'],
        'category_id' => ['type'=>'value']
    ];
    protected $_search_sorts = [ // 検索用ソートキー定義
        'id' => ['id'=>'ASC'],
        'name' => ['name'=>'ASC', 'modified'=>'DESC'],
    ];

    protected $_uploader_model = '';
    protected $_uploader_fields = [
    ];

    // ソート済みデータを取得する
    public function get_sorted () {
        $data = $this->db
                    ->from($this->_table)
                    ->where('category_id', set_value('category_id'))
                    ->order_by('sort_no', 'ASC')
                    ->get()
                    ->result_array();

        // after findのコール
        if (!empty($data) && method_exists($this, '_after_find')) {
            $data = $this->_after_find($data);
        }
        return $data;
    }

    // ソートを保存する
    public function save_sorted ($ids) {
        if (is_string($ids)) {
            $ids = explode(',', $ids);
        }
        if (!empty($ids)) {
            $this->db->trans_begin(); // トランザクション開始

            $sort_no = 1;
            foreach ($ids as $id) {
                if (empty($id)) continue;
                $save = [
                    'sort_no' => $sort_no++,
                ];
                if ($this->db->update($this->_table, $save, ['id' => $id])) {
                    log_message('debug', sprintf('%sの並び順保存に成功しました。DATA:%s', $this->_entity_name, print_r($save,true)));
                } else {
                    log_message('error', sprintf('%sの並び順保存に失敗しました。DATA:%s', $this->_entity_name, print_r($save,true)));
                    $this->db->trans_rollback(); // トランザクションロールバック
                    return false;
                }
            }
            $this->db->trans_commit(); // トランザクションコミット
        }
        return true;
    }

    // _after_findフィルター実行時に
    // データレコード別に呼び出される
    protected function _append_data($data)
    {
        $data = parent::_append_data($data);    // デフォルトの付加情報追加

        if( $data['category_id'] == DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT ){
            $data['detail_url'] = base_url('/treatment/special_foreign/'.$data['dir_name']);
        }
        else if( $data['category_id'] == DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT ){
            $data['detail_url'] = base_url('/treatment/kango_care/'.$data['dir_name']);
        }
        else {
            $data['detail_url'] = base_url('/treatment/departments/'.$data['dir_name']);
        }
        
        if( empty($data['is_temporary']) ){
            // 実績表示 ///////////////////////////////////////////////
            $arr = $this->db
                ->from($this->_results_table)
                ->where('department_id', $data['id'])
                ->order_by('sort_no', 'ASC')
                ->get()
                ->result_array();

            if (!empty($arr)) {
                foreach ($arr as $d) {
                    $data['result_html'][] = $d['html'];
                    $data['result_title'][] = $d['title'];
                }
            }
        }

        // 医療スタッフ表示 ///////////////////////////////////////////////
        $arr = $this->db
             ->from('department_doctors')
             ->where('department_id', $data['id'])
             ->join('doctors', 'department_doctors.doctor_id=doctors.id', 'left')
             ->order_by('sort_no', 'ASC')
             ->get()
             ->result_array();
        if (!empty($arr)) {
            foreach ($arr as $d) {
                $data['doctor_id'][] = $d['doctor_id'];
                $data['doctor_name'][] = $d['name'];
                $data['doctor_image'][] = $d['face_image_path'];
                $data['doctor_position'][] = $d['position'];
            }
        }

        return $data;
    }

    // 保存前処理
    // オーバーライドして使用
    // $data: 保存対象データ
    // $id: 保存対象のID(新規、および複製の場合はnull)
    // $raw: 指定された生のデータ(複製時は複製元データ)
    // 戻り値： 加工した保存対象データ or エラー時はfalse
    protected function _before_save($data, $id=null, $raw=[], $context='edit')
    {
        if( !empty($data['name_kana']) )
            $data['kana_index'] = syllabary($data['name_kana']);
        return $data;
    }

    // 保存後処理
    // リレーションテーブル操作については_before_saveではなくこちらに記述
    // オーバーライドして使用
    // $data: 保存対象データ
    // $id: 保存対象のID
    // $raw: 指定された生のデータ
    // $context: 呼び出し元の処理(edit / replicate)
    // 戻り値： 成功時=true 失敗時=false
    protected function _after_save($data, $id, $raw=[], $context='')
    {
        $ret = parent::_after_save($data, $id, $raw, $context); // アップローダと連携する場合はparent::_after_saveを呼び出すのを忘れないこと
        if (!$ret) return false;

        if ($context == 'edit') {
            // 編集時のみ（複製時は実行しない）

            // オリジナルtableのみの処理
            // if (!preg_match('/_tmp$/', $this->_table)) {
                // 医師登録 ///////////////////////////////////////////////
                // 空の時は処理しない(予約対策)
                //if (!empty($raw['doctor_id'])) {
                //    $rel_table = 'department_doctors';
                //    if (!empty($id)) { // 更新時
                //        // 一旦関連データを削除する
                //        $this->db
                //            ->where('department_id',$id)
                //            ->delete($rel_table);
                //    }

                //    $arr = $raw['doctor_id'] ?? [];
                //    $sort = 0;
                //    foreach ($arr as $idx => $v) {
                //        $doctor_id = $v;
                //        $save = [
                //            'department_id' => $id,
                //            'doctor_id' => $doctor_id,
                //            'sort_no' => ++$sort,
                //        ];
                //        $ret = $this->db->insert($rel_table, $save);
                //        if (!$ret) return false;
                //    }
                //}

                // 医療スタッフ登録 ///////////////////////////////////////////////
                // 空の時は処理しない(予約対策)
                if (!empty($raw['doctor_id'])) {
                    $rel_table = 'department_doctors';
                    if (!empty($id)) { // 更新時
                        // 一旦関連データを削除する
                        $this->db
                            ->where('department_id',$id)
                            ->delete($rel_table);
                    }

                    $arr = $raw['doctor_id'] ?? [];
                    $sort = 0;
                    foreach ($arr as $idx => $v) {
                        $doctor_id = $v;
                        $save = [
                            'department_id' => $id,
                            'doctor_id' => $doctor_id,
                            'sort_no' => ++$sort,
                        ];
                        $ret = $this->db->insert($rel_table, $save);
                        if (!$ret) return false;
                    }
                }
            // }

            // 実績登録 ///////////////////////////////////////////////
            $rel_table = $this->_results_table;
            if (!empty($id)) { // 更新時
                // 一旦関連データを削除する
                $this->db
                    ->where('department_id',$id)
                    ->delete($rel_table);
            }

            $arr = $raw['result_html'] ?? [];
            $i = 0;
            foreach ($arr as $idx => $v) {
                $save = [
                    'department_id' => $id,
                    'title' => $raw['result_title'][$i],
                    'html' => $raw['result_html'][$i],
                    'sort_no' => $i+1,
                ];
                $ret = $this->db->insert($rel_table, $save);
                $i++;
            }
        }

        if($context === 'temporary'){
            $search_text = [];
            $search_text[] = $raw['name'];
            $this->db->update($this->_table, [
                'search_text' => implode("\n", $search_text)
            ], ['id' => $id]);
        }

        // ここは編集時も複製時も実行される


        return true;
    }

    // 複製後処理
    // オーバーライドして使用
    // $data: 保存データ
    // $src_id: 複製元のID
    // $dest_id: 複製先のID
    // 戻り値： 成功時=true 失敗時=false
    protected function _after_replicate($data, $src_id, $dest_id)
    {
        parent::_after_replicate($data, $src_id, $dest_id);

        // ディレクトリ名の重複を避けるため_copyを末尾に付ける
        $save = [
            'dir_name' => $data['dir_name'].'_copy',
        ];
        $this->db->update($this->_table, $save, ['id'=>$dest_id]);

        // 複製時にFAQをコピーする
        // $table = 'department_questions';
        // $qas = $this->db
        //     ->where(['department_id'=>$src_id])
        //     ->from($table)
        //     ->get()
        //     ->result_array();
        // $save = [];
        // if (!empty($qas)) {
        //     foreach ($qas as $v) {
        //         unset($v['id']);
        //         $v['department_id'] = $dest_id;
        //         if (!$this->db->insert($table, $v)) {
        //             // 登録失敗
        //             return false;
        //         }
        //     }
        // }

        // 複製時に医師をコピーする
        $table = 'department_doctors';
        $qas = $this->db
            ->where(['department_id'=>$src_id])
            ->from($table)
            ->get()
            ->result_array();
        $save = [];
        if (!empty($qas)) {
            foreach ($qas as $v) {
                unset($v['id']);
                $v['department_id'] = $dest_id;
                if (!$this->db->insert($table, $v)) {
                    // 登録失敗
                    return false;
                }
            }
        }

        return true;
    }

    // 削除前処理
    // $id: 削除対象のID
    // 戻り値: 成功=true 失敗=false
    protected function _before_delete($id)
    {
        // 関連するテーブル削除
        $this->db
            ->where('department_id',$id)
            ->delete('schedule_doctors');

        $this->db
            ->where('department_id',$id)
            ->delete('department_results');

        $this->db
            ->where('department_id',$id)
            ->delete('department_doctors');

        return true;
    }

    public function save_temporary($data, $id, $atomic=true, $callback=true)
    {
        foreach(['doctor_id','doctor_name','doctor_image'] as $field){
            if( isset($data[$field]) ) unset($data[$field]);
        }
        return parent::save_temporary($data, $id, $atomic, $callback);
    }
}
