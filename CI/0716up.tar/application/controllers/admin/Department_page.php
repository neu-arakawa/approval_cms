<?php
class Department_page extends Admin_Controller
{
    const ENTITY_NAME = '診療科 固定ページ';
    const VIEW_ICON = '<i class="fas fa-question-circle"></i>';

    protected $_cms_uploader_model = 'department_page'; // CMS連携アップローダモデル名（サブディレクトリ名）

    protected $_exec_methods = [                        // 基本操作系メソッドの中で実行を許可するメソッド(この設定はAdminControllerに定義されていないメソッドには影響を与えない)
        'index', 'add', 'edit',
        'delete', 'delete_all',
        'replicate', 'replicate_all',
        'publish', 'publish_all',
        'clear_temporary'
    ];

    protected $_department_id = null;

    public function index($department_id=null) {
        if (empty($department_id)) show_404();
        $this->set_page_info($department_id);

        $this->_department_id = $department_id;
        
        // 診療科IDは固定条件
        $_POST['department_id'] = $_GET['department_id'] = $this->_department_id;

        parent::index();
    }

    // 追加処理
    public function add($department_id=null) 
    {
        if (empty($department_id)) show_404();
    
        // 編集アクションに転送
        admin_redirect($this->_controller_name."/{$department_id}/edit");
    }

    // 編集処理
    public function edit($department_id=null, $id=null) 
    {
        if (empty($department_id)) show_404();
        $this->set_page_info($department_id); // 診療科情報をセット
        
        $this->_department_id = $department_id;
        parent::edit($id);
    }

    public function delete($department_id=null, $id=null) 
    {
        if (empty($department_id)) show_404();
        $this->_department_id = $department_id;
        parent::delete($id);
    }

    public function delete_all($department_id=null)
    {
        if (empty($department_id)) show_404();
        $this->_department_id = $department_id;
        parent::delete_all();
    }

    public function replicate($department_id=null, $id=null)
    {
        if (empty($department_id)) show_404();
        $this->_department_id = $department_id;
        parent::replicate($id);
    }

    public function replicate_all($department_id=null)
    {
        if (empty($department_id)) show_404();
        $this->_department_id = $department_id;
        parent::replicate_all();
    }

    public function publish($department_id=null, $id=null, $flg=null)
    {
        if (empty($department_id)) show_404();
        $this->_department_id = $department_id;
        parent::publish($id, $flg);
    }

    public function publish_all($department_id=null, $flg=null)
    {
        if (empty($department_id)) show_404();
        $this->_department_id = $department_id;
        parent::publish_all($flg);
    }

    // 並び順の保存処理
    public function save_order () 
    {
        if (!empty(set_value('ids'))) {
            // 並び順の送信あり
            if ($this->_model->save_order( set_value('department_id'), set_value('ids') )) {
                $response = array(
                    'status' => 'success',
                );
            } else {
                $response = array(
                    'status' => 'error',
                );
            }
            //admin_redirect("/{$this->_controller_name}/{$department_id}");
            echo json_encode($response); 
        }
    }

    
    // コールバック処理 //////////////////////////////////////////////////////////

    // 保存処理時コールバック
    // $data: 保存対象データ
    protected function _complete($data) {
        $this->_delete_view_cache(); // VIEWキャッシュの削除
        $data['department_id'] = $this->_department_id; // 診療科IDをセット
        parent::_complete($data);
        admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
    }

    // 下書き保存時コールバック
    // $data: 保存対象データ
    protected function _draft($data) {
        $this->_delete_view_cache(); // VIEWキャッシュの削除
        $data['department_id'] = $this->_department_id; // 診療科IDをセット
        parent::_draft($data);
        admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
    }

    // キャンセル時コールバック
    protected function _cancel()
    {
        parent::_cancel();
        admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
    }

    // 削除時コールバック
    protected function _delete($id) {
        $this->_delete_view_cache(); // VIEWキャッシュの削除
        parent::_delete($id);
        admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
    }

    // 複製時コールバック
    protected function _replicate($id) {
        if ($save_id = parent::_replicate($id)) { // 成功
            admin_redirect($this->_controller_name.'/'.$this->_department_id. '/edit/'.$save_id);   // 編集画面にリダイレクト
        } else { // 失敗
            admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
        }
    }

    protected function _publish($id, $flg) {
        $this->_delete_view_cache(); // VIEWキャッシュの削除
        parent::_publish($id, $flg);
        admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
    }

    protected function _replicate_all() {
        parent::_replicate_all();
        admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
    }

    protected function _delete_all() {
        $this->_delete_view_cache(); // VIEWキャッシュの削除
        parent::_delete_all();
        admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
    }

    protected function _publish_all($flg) {
        $this->_delete_view_cache(); // VIEWキャッシュの削除
        parent::_publish_all($flg);
        admin_redirect($this->_controller_name.'/'.$this->_department_id);   // 一覧にリダイレクト
    }
    
    protected function set_page_info($department_id) 
    {
        // 診療科情報を読み込む
        $m = $this->_load_model('Admin_department_model');
        $data = $m->get_by_id($department_id);
        // if (empty($data) || $data['type']!=DEPARTMENT_TYPE_DEPARTMENT) show_404();
        $department_name = $data['name'];
        $department = $data;
        $sub_title = '<span class="badge badge-pill badge-secondary text-sm">'.h($department_name).'</span>';

        $this->load->vars(compact('department_id', 'department_name', 'sub_title','department'));
    }

    // VIEWキャッシュの削除
    protected function _delete_view_cache () {
        // ひとまずVIEWキャッシュを全て削除
        $this->_delete_all_cache();
    }

    public function _is_unique_by_department_id($str,$field) {
        $this->form_validation->set_message('_is_unique_by_department_id', 'ユニークな値でなければなりません');
        $model_id = $this->get_model_id(); // 編集対象のIDを取得
        sscanf($field, '%[^.].%[^.]', $table, $field);
        if (isset($this->db)) {
            $db = $this->db
                    ->from($table)
                    ->where($field, $str)
                    ->limit(1);
            $db->where('department_id', $this->_department_id);
            if (!empty($model_id)) {
                $db->where('id <>', $model_id);
            }
            if ($db->count_all_results()===0) return true;
        }
        return false;
    }

    // 一時保存処理時コールバック
    // $data: 保存対象データ
    protected function _temporary($data)
    {
        parent::_temporary($data);
        admin_redirect($this->_controller_name.'/'.
            $this->_department_id);
    }

    // 一次保存クリア
    public function clear_temporary($id)
    {
        // 保存処理
        $save_id = $this->_model->clear_temporary($id);
        if ($save_id) { // 保存成功
            // 操作ログ保存
            $this->_save_ope_log(
                $save_id, '一時保存クリア', true, "一時保存クリア時のタイトル:". strip_tags($this->_model->get_last_title())
            );
            // フラッシュメッセージ設定
            $this->flash->info(
                sprintf('ID:%s「%s」の一時保存をクリアしました', $save_id, strip_tags($this->_model->get_last_title()))
            );
            redirect($_SERVER['HTTP_REFERER']);
        } else { // 失敗
            // 操作ログ保存
            $this->_save_ope_log(
                $save_id, '一時保存クリア', false, "一時保存対象ID:". $this->_model_id
            );
            // フラッシュメッセージ設定
            $this->flash->error(
                sprintf('ID:%s の一時保存に失敗しました', $this->_model_id)
            );
        }
    }

}
