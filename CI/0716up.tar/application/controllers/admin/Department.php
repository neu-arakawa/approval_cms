<?php
class Department extends Admin_Controller
{
    const ENTITY_NAME = '診療科・部門';
    const VIEW_ICON = '<i class="fas fa-hospital"></i>';

    protected $_cms_uploader_model = 'department'; // CMS連携アップローダモデル名（サブディレクトリ名）

    protected $_exec_methods = [                        // 基本操作系メソッドの中で実行を許可するメソッド(この設定はAdminControllerに定義されていないメソッドには影響を与えない)
        'index', 'add', 'edit',
        'delete', 'delete_all',
        'replicate', 'replicate_all',
        'publish', 'publish_all',
        'clear_temporary'
    ];

    // 一覧表示アクション
    public function index()
    {
        parent::index();
    }

    // 並び順の保存処理
    public function sort () 
    {
        if (!empty($_GET['ids'])) {
            // 並び順の送信あり
            if ($this->_model->save_sorted($_GET['ids'])) {
                // 保存成功
                $this->_save_ope_log(
                    null, '並び順保存', true, sprintf('並び順:%s', $_GET['ids'])
                );
                // フラッシュメッセージ設定
                $this->flash->info(
                    sprintf('並び順の保存が完了しました')
                );
            } else {
                // 保存失敗
                $this->_save_ope_log(
                    null, '並び順保存', false, sprintf('並び順:%s', $_GET['ids'])
                );
                $this->flash->error(
                    sprintf('並び順の保存に失敗しました')
                );
            }
            admin_redirect('/department/sort?category_id='.set_value('category_id',1));
        } else {
            $_GET['category_id'] = set_value('category_id',1);
            // ソート済み一覧を取得
            $sorted = $this->_model->get_sorted();
            $this->load->view('admin/department/sort', compact('sorted'));
        }
    }

    protected function before_validate($group=null, $data=null) 
    {
        // 施設の画像用バリデーション
        // if (!empty($data['facility_caption']) && is_array($data['facility_caption'])) {
        //     $num = 1;
        //     foreach ($data['facility_caption'] as $idx => $caption) {
        //         $img = $data['facility_image_path'][$idx] ?? null;
        //         $url = $data['facility_url'][$idx] ?? null;

        //         if (($url || $caption) && !$img) {
        //             $this->form_validation->set_required($group, "facility_image_path[$idx]", lang('facility_image_path').$num);
        //         }
        //         $num++;
        //     }
        // }

        // 実績バリデーション
        //if (!empty($_POST['result_year']) && is_array($_POST['result_year'])) {
        //    $num = 1;
        //    foreach ($_POST['result_year'] as $idx => $year) {
        //        $html = $_POST['result_html'][$idx] ?? null;

        //        if ($year && !$html) {
        //            $this->form_validation->set_required($group, "result_html[$idx]", lang('result_html').$num);
        //        } else if (!$year && $html) {
        //            $this->form_validation->set_required($group, "result_year[$idx]", lang('result_year').$num);
        //        }

        //        if ($year) {
        //            $this->form_validation->set_rule($group, "result_year[$idx]", 'is_natural_no_zero', lang('result_year').$num);
        //        }
        //        $num++;
        //    }
        //}

        // ごあいさつバリデーション
        // if (!empty($_POST['intro_image_caption']) && empty($_POST['intro_image_path'])) {
        //     $this->form_validation->set_required($group, "intro_image_path");
        // }
        // // 診療体制バリデーション
        // if (!empty($_POST['system_image_caption']) && empty($_POST['system_image_path'])) {
        //     $this->form_validation->set_required($group, "system_image_path");
        // }
        // // 高度な専門医療バリデーション
        // if (!empty($_POST['highlevel_image_caption']) && empty($_POST['highlevel_image_path'])) {
        //     $this->form_validation->set_required($group, "highlevel_image_path");
        // }
        
    }

    // 保存処理時コールバック
    // $data: 保存対象データ
    protected function _complete($data) {
        $this->_delete_view_cache();
        return parent::_complete($data);
    }
    // 削除時コールバック
    protected function _delete($id) {
        $this->_delete_view_cache();
        return parent::_delete($id);
    }
    // 公開／下書き処理時コールバック
    protected function _publish($id, $flg) {
        $this->_delete_view_cache();
        return parent::_publish($id, $flg);
    }
    // 下書き保存時コールバック(編集画面経由)
    protected function _draft($data) {
        $this->_delete_view_cache();
        return parent::_draft($data);
    }
    // 一括削除時コールバック
    protected function _delete_all() {
        $this->_delete_view_cache();
        return parent::_delete_all();
    }
    // 一括公開／下書き処理コールバック
    protected function _publish_all($flg) {
        $this->_delete_view_cache();
        return parent::_publish_all($flg);
    }

    // VIEWキャッシュの削除
    protected function _delete_view_cache () {
        // ひとまずVIEWキャッシュを全て削除
        $this->_delete_all_cache();
    }
}
