<?php /* 編集画面と確認画面共通のテンプレート */ ?>

<?php include_once VIEWPATH.'admin/common/info_block.php'; ?>

<div class="edit-box">
    <h3>基本設定</h3>
    <table class="table table-bordered dataTable">
        <tbody>
            <?php echo admin_form_row(!empty($model_id)?$model_id:'(自動で採番されます)', 'ID', null, 'col-md-8');?>
            <?php echo admin_form_input('disp_date', date('Y-m-d',NOW_TIME), ['class'=>'datepicker'], 'col-md-12 col-lg-6');?>
            <?php echo admin_form_input('title', null, null, 'col-lg-12');?>
            <?php echo admin_form_dropdown('department_ids[]', DepartmentConf::name_options(), null, ['class'=>'select2', 'empty'=>false], 'col-md-12');?>
            <?php echo admin_form_attach_image('image_path', null, ['data-uploader-dir'=>'/topic/thumbnail','notice'=>'推奨サイズ: 720×540ピクセル'], 'col-lg-12');?>
            <?php echo admin_form_checkbox('disp_place[]', TopicConf::$disp_place_options, null, ['inline'=>true, 'empty'=>false], 'col-md-12');?>
            <?php echo admin_form_radio('link_type', TopicConf::$link_type_options, null, ['inline'=>true, 'empty'=>false], 'col-md-12');?>
            <?php echo admin_form_input('external_url', null, ['wrap_class'=>'link_type_'.TOPIC_LINK_TYPE_URL.' link_type', 'required'=>true], 'col-lg-12');?>
            <?php echo admin_form_attach_file('attach_path', null, ['data-uploader-dir'=>'/topic/attach', 'wrap_class'=>'link_type_'.TOPIC_LINK_TYPE_ATTACH.' link_type', 'required'=>true], 'col-lg-12');?>
        </tbody>
        <tfoot>
        </tfoot>
    </table>
</div>
<!-- //.edit-box -->

<div class="edit-box <?php echo !_is_validated('content_html')?'error':'' ?> link_type_<?php echo TOPIC_LINK_TYPE_CONTENT?> link_type">
    <h3>本文設定 <?php echo admin_required_badge() ?></h3>
    <?php echo admin_form_article_editor_raw(
        'content_html',
        null,
        [
            'data-inline-ve'=>1,
            'data-types'=>"['big-heading', 'mid-heading', 'small-heading', 'text', 'image', 'link', 'table', 'youtube']",
            'data-big-heading-tag'=>'h3',
            'data-mid-heading-tag'=>'h4',
            'data-small-heading-tag'=>'h5',
            'data-uploader-dir'=>'/topic/content'
        ]
    );?>

</div>

<div class="edit-box link_type_<?php echo TOPIC_LINK_TYPE_CONTENT?> link_type">
    <h3>ページ設定</h3>
    <p class="small mb-1">デフォルトのmeta情報以外を設定したい場合のみ記入してください。</p>
    <table class="table table-bordered dataTable">
        <tbody>
            <?php echo admin_form_input('meta_title', null, [], 'col-md-12');?>
            <?php echo admin_form_input('meta_description', null, null, 'col-md-12');?>
        </tbody>
    </table>
</div>

<?php include_once VIEWPATH.'admin/common/publish_block.php'; ?>

<?php
if (empty($confirm_flag)) echo admin_input_buttons(['temporary' => '一時保存（公開待機）']);
else echo admin_confirm_buttons();
?>

<link rel="stylesheet" href="<?php echo base_url('/admin/js/select2/css/select2.css')?>">
<script src="<?php echo base_url('/admin/js/select2/js/select2.full.min.js');?>"></script>
<script>
$('.select2').select2({
    'placeholder': '選択してください'
});
// リンク種類による入力フィールドの切り替え
var $all_elms = $('.link_type');
var post_link_type = '<?php echo !empty($_POST['link_type']) ? $_POST['link_type'] : '' ?>';

// 入力フォーム用
$('input[name="link_type"]').bind('change', function(){
    var val = $(this).val();
    show_link_type(val);
});
function show_link_type(type){
    $all_elms.hide();
    $('.link_type_'+type).show();
}
show_link_type(post_link_type);
</script>
