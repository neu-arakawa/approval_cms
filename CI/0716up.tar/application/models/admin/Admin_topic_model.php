<?php
class Admin_topic_model extends MY_Model
{
    protected $_table = 'topics';
    protected $_title_field = 'title';          // 見出しとして使用するフィールド名

    // limitを設定すると、[20件 50件 100件 全件]などの
    // ユーザによるlimit選択機能が使用できなくなるので注意
    protected $_search_options = [
        'order_by' => ['modified'=>'DESC', 'id'=>'DESC'],
    ];
    protected $_search_fields = [ // 検索処理用の定義
        'keyword' => ['type'=>'query', 'method'=>'_search_keyword', 'field'=>['title','content_html','search_text']],
        'published' => ['type'=>'query', 'method'=>'_search_published'],
        'draft' => ['type'=>'query', 'method'=>'_search_draft'],
        'category_id' => ['type'=>'value']
    ];
    protected $_search_sorts = [ // 検索用ソートキー定義
        'id' => ['id'=>'ASC'],
        'disp_date' => ['disp_date'=>'ASC'],
        'title' => ['title'=>'ASC', 'modified'=>'DESC'],
        'category_id' => ['category_id'=>'ASC', 'modified'=>'DESC'],
    ];

    protected $_uploader_model = 'topic';
    protected $_uploader_fields = [
        'content_html', 'attach_path',
    ];

    // _after_findフィルター実行時に
    // データレコード別に呼び出される
    protected function _append_data($data)
    {
        $data = parent::_append_data($data);    // デフォルトの付加情報追加
        $data['detail_url'] = base_url('/topic/detail/'.$data['id']); // 詳細画面URLの追加
        if( !empty($data['department_ids'])  )
            $data['department_ids'] = explode(',', $data['department_ids']);
        if( !empty($data['disp_place'])  )
            $data['disp_place'] = explode(',', $data['disp_place']);
        return $data;
    }

    protected function _before_save($data, $id=null, $raw=[], $context='')
    {
        $data = parent::_before_save($data, $id, $raw, $context='');
        // 掲載場所をカンマ区切りにする
        if (!empty($data['disp_place']) && is_array($data['disp_place'])) {
            $data['disp_place'] = implode(',', array_filter($data['disp_place']));
        }
        if (!empty($data['department_ids']) && is_array($data['department_ids'])) {
            $data['department_ids'] = implode(',', array_filter($data['department_ids']));
        }
        else {
            $data['department_ids'] = null;
        }
        
        return $data;
    }

    protected function _after_save($data, $id, $raw=[], $context='')
    {
        $data = parent::_after_save($data, $id, $raw, $context);

        if($context === 'temporary'){
            $search_text = [];
            $search_text[] = $raw['title'];
            $search_text[] = $raw['content_html'];
            $this->db->update($this->_table, [
                'search_text' => implode("\n", $search_text)
            ], ['id' => $id]);
        }
        return true;
    }

}
