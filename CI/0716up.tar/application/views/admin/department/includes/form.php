<?php /* 編集画面と確認画面共通のテンプレート */ ?>

<?php include_once VIEWPATH.'admin/common/info_block.php'; ?>

<div class="edit-box">
    <h3>基本情報</h3>
    <table class="table table-bordered dataTable">
        <tbody>
            <?php echo admin_form_row(!empty($model_id)?$model_id:'(自動で採番されます)', 'ID', null, 'col-md-8');?>
            <?php echo admin_form_input('name', null, null, 'col-md-12');?>
            <?php echo admin_form_input('name_kana', null, null, 'col-md-12');?>
            <?php echo admin_form_dropdown('category_id', DepartmentConf::$category_options, null, null, 'col-auto');?>
            <?php echo admin_form_checkbox('flg_second_opinion', [1=>'セカンドオピニオン外来ページに診療日程表へのリンクを表示'], null, ['inline'=>true])?>
            <?php echo admin_form_input('dir_name', null, ['before_input'=>'-', 'notice'=>'使用できる文字は3文字以上の半角英数字、および_(アンダースコア)のみです'], 'col-lg-4');?>
            <?php echo admin_form_input('reception_place', null, null, 'col-md-12');?>
            <?php echo admin_form_input('reception_place_url', null, ['notice'=>'URLからドメイン（https://hp.kmu.ac.jp）を取り、最後に#mapTargetを追加したURLを記載してください。<br>＜例＞小児科の場合：/facility/room_map/?mapName=小児科#mapTarget'], 'col-md-12');?>
        </tbody>
        <tfoot>
        </tfoot>
    </table>
</div>
<!-- //.edit-box -->

<div class="edit-box">
    <h3>本文設定（上）</h3>
    <small class="form-text text-muted mb-2">
        画像（特色・強み）の画像の推奨サイズは、846x524ピクセルになります。<br>
        画像（PCのみ2カラム）の画像の推奨サイズは、846x546ピクセルになります。
    </small>
    <?php echo admin_form_article_editor_raw(
        'content1_html',
        null,
        [
            'data-inline-ve'=>1,
            'data-types'=>"['big-heading', 'mid-heading', 'text', 'image', 'image-kmu', 'vs-image', 'link-kmu', 'table', 'youtube']",
            'data-type-names'=>"{'big-heading':'大見出し', 'mid-heading':'子見出し', 'text':'テキスト', 'image-kmu':'画像（特色・強み）', 'vs-image':'画像（PCのみ2カラム）', 'image':'画像', 'link-kmu':'リンクボタン', 'table':'表', 'youtube':'YouTube'}",
            'data-big-heading-tag'=>'h2',
            'data-mid-heading-tag'=>'h3',
            'data-uploader-dir'=>'/department/content'
        ]
    );?>
</div>
<!-- //.edit-box -->

<div class="edit-box">
    <h3>主な対象疾患</h3>
    <?php echo admin_form_article_editor_raw(
        'target_diseases_html',
        null,
        [
            'data-inline-ve'=>1,
            'data-types'=>"['list-kmu', 'text']",
            'data-type-names'=>"{'list-kmu':'疾患', 'text':'テキスト'}",
            // 'data-uploader-dir'=>'/department/diseases'
        ]
    );?>
</div>
<!-- //.edit-box -->

<div class="edit-box">
    <h3>各種実績</h3>
    <button class="btn btn-secondary btn-xs js-add-result only-input"><i class="fas fa-plus"></i> 追加</button>
    <ul class="result">
        <?php 
        $func = function ($idx=null) use ($confirm_flag) {
            if ($idx!==null && 
                empty($_POST['result_html'][$idx]) &&
                empty($_POST['result_title'][$idx]) ) {
                // 全て未入力なら表示しない
                return null;
            }

            $editor = @admin_form_article_editor_raw(
                "result_html[$idx]",
                null,
                [
                    'data-inline-ve'=>1,
                    'data-types'=>"['table', 'text']",
                    'data-big-heading-tag'=>'h3',
                    'data-type-names'=>"{'big-heading':'見出し', 'table':'表組み', 'text':'備考'}",
                ]
            );

            // 年部分の横幅
            if ($confirm_flag) $year_col = 'col-auto';
            else $year_col = 'col-md-10';
            $year = '<div class="row">'.
                    '<div class="'.$year_col.' pr-0">'.
                    @admin_form_input_raw(
                        "result_title[$idx]",
                        null
                    )
                .'</div>'
                .'</div>';

            return "<li class=\"js-result-item card-body\">
                        <h6 class=\"card-subtitle mb-2 mt-2 text-muted\">実績</h6>
                        <div class=\"row\">
                            <div class=\"col-md-4\">{$year}</div>
                            <div class=\"col-md-12\">{$editor}</div>
                        </div>
                        <div class=\"close only-input\"></div>
                    </li>";
        };

        $arr = $_POST['result_title'] ?? [0];
        foreach ($arr as $idx => $d) {
            echo $func($idx);
        }
        $res_item_dom = $func(); // JS用のデータ
        ?>
    </ul>
</div>
<!-- //.edit-box -->

<div class="edit-box">
    <h3>本文設定（下）</h3>
    <small class="form-text text-muted mb-2">
        画像（特色・強み）の画像の推奨サイズは、846x524ピクセルになります。<br>
        画像（PCのみ2カラム）の画像の推奨サイズは、846x546ピクセルになります。
    </small>
    <?php echo admin_form_article_editor_raw(
        'content2_html',
        null,
        [
            'data-inline-ve'=>1,
            'data-types'=>"['big-heading', 'mid-heading', 'text', 'image', 'image-kmu', 'vs-image','link-kmu','table', 'youtube']",
            'data-type-names'=>"{'big-heading':'大見出し', 'mid-heading':'子見出し', 'text':'テキスト', 'image-kmu':'画像（特色・強み）', 'image':'画像','vs-image': '画像（PCのみ2カラム）', 'link-kmu':'リンクボタン', 'table':'表', 'youtube':'YouTube'}",
            'data-uploader-dir'=>'/department/content',
            'data-big-heading-tag'=>'h2',
            'data-mid-heading-tag'=>'h3',
        ]
    );?>
</div>
<!-- //.edit-box -->
<div class="edit-box">
    <h3>よく見られているページ</h3>
    <?php echo admin_form_article_editor_raw(
        'related_link_html',
        null,
        [
            'data-inline-ve'=>1,
            'data-types'=>"['mid-heading', 'text', 'list-link-kmu']",
            'data-type-names'=>"{'mid-heading':'見出し', 'text':'テキスト', 'list-link-kmu':'リンク'}",
            'data-mid-heading-tag'=>'h3',
        ]
    );?>
</div>
<!-- //.edit-box -->

<div class="edit-box doctor">
    <h3>スタッフ設定</h3>

    <?php 
    $func = function($idx=null) {

        if ($idx!==null && 
            empty($_POST['doctor_id'][$idx]) &&
            empty($_POST['doctor_name'][$idx]) && 
            empty($_POST['doctor_image'][$idx]) ) {
            // 全て未入力なら表示しない
            return null;
        }
        $name = $_POST['doctor_name'][$idx] ?? '';
        $position = $_POST['doctor_position'][$idx] ?? '';
        $image = !empty($_POST['doctor_image'][$idx] ) ? 
            $_POST['doctor_image'][$idx] : '/admin/img/no_doctor_image.jpg';
        $image = "<img src=\"{$image}\">";
        $hidden = @admin_form_hidden_raw(
            "doctor_id[$idx]", 
            null,
            null
        );
        $hidden .= @admin_form_hidden_raw(
                        "doctor_image[$idx]", 
                        null,
                        null
                    );
        $hidden .= @admin_form_hidden_raw(
            "doctor_name[$idx]", 
            null,
            null
        );
        return "<div class=\"js-doctor-item col-sm-4 col-md-4 col-lg-3 mb-3\">
            <div class=\"card\">
                <div class=\"card-body pl-2 pr-2\">
                    <h6 class=\"card-subtitle mb-2 text-muted\">{$name}</h6>
                    <div class=\"float-left\">{$image}</div>
                    {$hidden} 
                    <div class=\"float-left ml-2\"><small>役職: {$position}</small></div>
                </div>
                <div class=\"close only-input\"></div>
            </div>
        </div>";
    };
    $doc_item_dom = $func(); // JS用のデータ
    ?>

    <?php if (!empty($_POST['doctor_id'])):?>
    <div class="form-text text-muted text-xs mb-3">各項目の <i class="fas fa-bars"></i> をマウスでクリックしてドラッグすると、項目の並び替えが可能です。</div>
    <div class="row">
    <?php
    $arr = $_POST['doctor_id'] ?? [];
    foreach ($arr as $idx => $v) {
        echo $func($idx);
    }
    ?>
    </div>
    <?php else:?>
    医師の登録はありません。
    <?php endif?>
</div>

<?php /*
<div class="edit-box">
    <h3>各科の診療実績（医療関係の方向け）</h3>
    <h4>紹介・受け入れ実績</h4>
    <?php echo admin_form_article_editor_raw(
        'achievement_html',
        null,
        [
            'data-inline-ve'=>0,
            'data-types'=>"['big-heading', 'mid-heading', 'small-heading', 'text', 'image', 'link', 'table', 'list']",
            'data-big-heading-tag'=>'h3',
            'data-mid-heading-tag'=>'h4',
            'data-small-heading-tag'=>'h5',
            'data-uploader-dir'=>'/department/achievement'
        ]
    );?>
</div>
<!-- //.edit-box -->
 */?>

<div class="edit-box">
    <h3>ページ設定</h3>
    <p class="small mb-1">デフォルトのmeta情報以外を設定したい場合のみ記入してください。</p>
    <table class="table table-bordered dataTable">
        <tbody>
            <?php echo admin_form_input('meta_title', null, [], 'col-md-12');?>
            <?php echo admin_form_input('meta_description', null, null, 'col-md-12');?>
        </tbody>
    </table>
</div>

<?php include_once VIEWPATH.'admin/common/publish_block.php'; ?>

<?php
if (empty($confirm_flag)) echo admin_input_buttons(['temporary' => '一時保存（公開待機）']);
else echo admin_confirm_buttons();
?>

<style>
.attach-upload img,
.attach-preview img{
    max-width: 100%!important;
}
.result {
    padding: 0;
    margin: 1rem 0;
}
.result > li {
    list-style-type: none;
    margin-bottom: 2rem;
    position: relative;
    background-clip: border-box;
    border: 1px solid rgba(0,0,0,.125);
    border-radius: .25rem;
    padding: .5rem .5rem;
    background-color: rgba(251, 251, 251, 1.0);
}
.result .close:before{
    font-family: fontAwesome;
    content: '\f057';
    position: absolute;
    top: -12px;
    right: -12px;
    color: #dc3545;
}

.facility *,
.doctor * {
    outline: none;
}
.card-body h6 {
    cursor: move;
}
.card-body h6:before {
    font-family: fontAwesome;
    content: '\f0c9';
    margin-right: .3rem;
    color: #ddd;
}
.confirm .card-body h6:before {
    content: '';
}
.card-body img[src=""] {
    display: none;
}
.card {
    background-color: rgba(251, 251, 251, 1.0);
    outline: none;
}
.card img{
    max-width: 100%!important;
}
.card .close:before{
    font-family: fontAwesome;
    content: '\f057';
    position: absolute;
    top: -12px;
    right: -12px;
    color: #dc3545;
}

.draggable-mirror{
    z-index: 1000000;
    opacity: .8;
}
.draggable-mirror .card{
    transform: scale(.5, .5);
    transition-property: scale;
    transition-duration: .4s;
    transition-delay: 0;
    transform-origin: top left;
}

</style>
<script src="<?php echo base_url('/admin/js/draggable.bundle.legacy.js');?>"></script>
<script>
$(document).ready(function(){
    if (isConfirm) return false; // 確認画面ならスキップ

    // 実績追加処理
    var $res_wrap = $('.result');
    var res_item_selector = '.result .js-result-item';
    var res_close_selector = '.result .js-result-item .close';
    var res_dom = '<?php 
        $dom = preg_replace('/(\r\n|\r|\n)+/', '',$res_item_dom);
        $dom = preg_replace('/value="([^"]*)"/', '', $dom);
        $dom = str_replace("'","\'",$dom);
        echo $dom;
    ?>';
    var $res_btn = $('.js-add-result');
    // 要素の追加
    $res_btn.bind('click', function(){
        var $add = $(res_dom);
        var $editor = $add.find('.article-editor');
        $res_wrap.prepend($add);

        new ArticleEditor(
            $editor[0],
            {uploaderPath: '<?php echo UPLOADER_DIR;?>'}
        );
        init_res_name();
        return false;
    });
    init_res_name();
    // 添え字の番号削除(添え字付となしが混ざると正常にPOSTが受信されないため)
    function init_res_name() {
        $(res_item_selector).find('input[name^="result"]').each(function(){
            var name = $(this).attr('name');
            name = name.replace(/\[\d+\]\s*$/, '[]');
            $(this).attr('name', name);
        });
    }
    // ドラッグ&ドロップ許可
    var sortable = new Draggable.Sortable($res_wrap[0],{
           draggable: res_item_selector,
           handle: 'h6'
       });
    var i = 1;
    $('.result .js-result-item').each(function(){
     $(this).find('h6').text('実績'+i);
     i++;
    });
    sortable.on('drag:stop', function(){
       setTimeout(function(){
           var i = 1;
           $('.result .js-result-item').each(function(){
            $(this).find('h6').text('実績'+i);
            i++;
           });

       },0);
    });

    // 要素の削除
    $(document).on('click', res_close_selector, function(){
        var $item = $(this).closest(res_item_selector);
        $item.remove();
        return false;
    });

    // 医師追加処理
    var $doc_wrap = $('.doctor .row');
    var doc_item_selector = '.doctor .row .js-doctor-item';
    var doc_close_selector = '.doctor .row .js-doctor-item .close';
    var doc_dom = '<?php 
        $dom = preg_replace('/(\r\n|\r|\n)+/', '',$doc_item_dom);
        $dom = preg_replace('/value="([^"]*)"/', '', $dom);
        echo $dom;
    ?>';
    var $doc_btn = $('.js-add-doctor');
    // 要素の追加
    $doc_btn.bind('click', function(){
        var $add = $(fac_dom);
        $doc_wrap.append($add);
        doc_init_number(); // ナンバー振り直し
        return false;
    });
    // 要素の削除
    $(document).on('click', doc_close_selector, function(){
        var $item = $(this).closest(doc_item_selector);
        $item.remove();

        doc_init_number();
        return false;
    });
    doc_init_number();

    // ドラッグ&ドロップ許可
    var sortable = new Draggable.Sortable($doc_wrap[0],{
            draggable: doc_item_selector,
            handle: 'h6'
        });
    sortable.on('drag:stop', function(){
        setTimeout(function(){
            doc_init_number(); // ナンバー振り直し
        },0);
    });
    
    // イメージ番号を振り直す
    function doc_init_number() {
        var i=1;
        $(doc_item_selector).each(function(){
            // $(this).find('h6').text('イメージ'+i);
            i++;
        });
        // 添え字の番号削除(添え字付となしが混ざると正常にPOSTが受信されないため)
        $(doc_item_selector).find('[name^="doctor"]').each(function(){
            var name = $(this).attr('name');
            name = name.replace(/\[\d+\]\s*$/, '[]');
            $(this).attr('name', name);
        });
    }


    $('[name=category_id]').bind('change', function(){
        if( $(this).val() == '<?= DEPARTMENT_CATEGORY_SPECIALTY_OUTPATIENT ?>' ){
            $('[name=dir_name]').parents('td').find('div span').text('<?= FULL_BASE_URL ?>/treatment/special_foreign/')
        }
        else if( $(this).val() == '<?= DEPARTMENT_CATEGORY_NURSING_CARE_OUTPATIENT ?>' ){
            $('[name=dir_name]').parents('td').find('div span').text('<?= FULL_BASE_URL ?>/treatment/kango_care/')
        }
        else {
            $('[name=dir_name]').parents('td').find('div span').text('<?= FULL_BASE_URL ?>/treatment/departments/')
        }
    });
    $('[name=category_id]').change();
});
</script>
